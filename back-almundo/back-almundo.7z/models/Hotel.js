const mongoose = require('mongoose');

let HotelSchema = new mongoose.Schema({
  name: String,
  stars: String,
  price: String,
  image: String,
  amenities: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Amenity' }]
});

module.exports = mongoose.model('Hotel', HotelSchema);
